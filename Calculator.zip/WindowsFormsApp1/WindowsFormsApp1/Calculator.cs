﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Calculator : Form
    {
        double input1;
        double input2;

        double angle;
        double radians;

        bool decimalPoint = false;

        bool plusButton = false;
        bool minusButton = false;
        bool divideButton = false;
        bool multiplyButton = false;
        
        bool mySinButton = false;
        bool myCosButton = false;
        bool myTanButton = false;

        bool mySqrt = false;
        bool myCbert = false;
        bool myInverse = false;

        public Calculator()
        {
            InitializeComponent();
        }

        private void oneButton_Click(object sender, EventArgs e)
        {
            inputOutput.Text = inputOutput.Text + oneButton.Text;
        }

        private void twoButton_Click(object sender, EventArgs e)
        {
            inputOutput.Text = inputOutput.Text + twoButton.Text;
        }

        private void threeButton_Click(object sender, EventArgs e)
        {
            inputOutput.Text = inputOutput.Text + threeButton.Text;
        }

        private void fourButton_Click(object sender, EventArgs e)
        {
            inputOutput.Text = inputOutput.Text + fourButton.Text;
        }

        private void fiveButton_Click(object sender, EventArgs e)
        {
            inputOutput.Text = inputOutput.Text + fiveButton.Text;
        }

        private void sixButton_Click(object sender, EventArgs e)
        {
            inputOutput.Text = inputOutput.Text + sixButton.Text;
        }

        private void sevenButton_Click(object sender, EventArgs e)
        {
            inputOutput.Text = inputOutput.Text + sevenButton.Text;
        }

        private void eightButton_Click(object sender, EventArgs e)
        {
            inputOutput.Text = inputOutput.Text + eightButton.Text;
        }

        private void nineButton_Click(object sender, EventArgs e)
        {
            inputOutput.Text = inputOutput.Text + nineButton.Text;
        }

        private void zeroButton_Click(object sender, EventArgs e)
        {
            inputOutput.Text = inputOutput.Text + zeroButton.Text;
        }

        private void decimalPoint_Click(object sender, EventArgs e)
        {
            //check to see if not already pressed
            if(!decimalPoint)
            {
                inputOutput.Text = inputOutput.Text + decimalPointButton.Text;
                decimalPoint = true;
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            inputOutput.Clear();
            //reset decimal point behaviour
            decimalPoint = false;
        }

        private void equalsButton_Click(object sender, EventArgs e)
        {
            if (plusButton == true)
            {
                input2 = BasicMath.Arithmetic.Add(input1, double.Parse(inputOutput.Text));
            }
            else if (minusButton == true)
            {
                input2 = BasicMath.Arithmetic.Sub(input1, double.Parse(inputOutput.Text));
            }
            else if (divideButton == true)
            {
                input2 = BasicMath.Arithmetic.Div(input1, double.Parse(inputOutput.Text));
            }
            else if (multiplyButton == true)
            {
                input2 = BasicMath.Arithmetic.Mul(input1, double.Parse(inputOutput.Text));
            }
            else if(mySinButton == true)
            {
                if(double.Parse(inputOutput.Text) >= 90)
                {
                    MessageBox.Show("Too large an angle.");
                }
                else
                {
                    angle = Math.PI * double.Parse(inputOutput.Text) / 180;
                    input2 = Trigonometric.Trigonometric.sin(angle);
                }
            }
            else if(myCosButton == true)
            {
                if(double.Parse(inputOutput.Text) >= 90)
                {
                    MessageBox.Show("Too large an angle.");
                }
                else
                {
                    angle = Math.PI * double.Parse(inputOutput.Text) / 180;
                    input2 = Trigonometric.Trigonometric.cosine(angle);
                }
            }
            else if(myTanButton == true)
            {
                if(double.Parse(inputOutput.Text) >= 90)
                {
                    MessageBox.Show("Too large an angle");
                }
                else
                {
                    angle = double.Parse(inputOutput.Text);
                    radians = angle * (Math.PI / 180);
                    input2 = Trigonometric.Trigonometric.tan(radians);
                }
            }
            else if(mySqrt == true)
            {
                input2 = Algebraic.Algebra.sqrt(double.Parse(inputOutput.Text));
            }
            else if(myCbert == true)
            {
                input2 = Algebraic.Algebra.cubert(double.Parse(inputOutput.Text));
            }
            else if(myInverse == true)
            {
                input2 = Algebraic.Algebra.inverse(double.Parse(inputOutput.Text));
            }
            inputOutput.Text = input2.ToString();
            input1 = 0;
        }

        private void additionButton_Click(object sender, EventArgs e)
        {
            input1 += double.Parse(inputOutput.Text);
            inputOutput.Clear();

            plusButton = true;
            minusButton = false;
            divideButton = false;
            multiplyButton = false;

            decimalPoint = false;

            mySinButton = false;
            myCosButton = false;
            myTanButton = false;

            mySqrt = false;
            myCbert = false;
            myInverse = false;
        }

        private void subtractionButton_Click(object sender, EventArgs e)
        {
            input1 += double.Parse(inputOutput.Text);
            inputOutput.Clear();

            plusButton = false;
            minusButton = true;
            divideButton = false;
            multiplyButton = false;

            decimalPoint = false;

            mySinButton = false;
            myCosButton = false;
            myTanButton = false;

            mySqrt = false;
            myCbert = false;
            myInverse = false;
        }

        private void divisionButton_Click(object sender, EventArgs e)
        {
            input1 += double.Parse(inputOutput.Text);
            inputOutput.Clear();

            plusButton = false;
            minusButton = false;
            divideButton = true;
            multiplyButton = false;

            decimalPoint = false;

            mySinButton = false;
            myCosButton = false;
            myTanButton = false;

            mySqrt = false;
            myCbert = false;
            myInverse = false;
        }

        private void multiplicationButton_Click(object sender, EventArgs e)
        {
            input1 += double.Parse(inputOutput.Text);
            inputOutput.Clear();

            plusButton = false;
            minusButton = false;
            divideButton = false;
            multiplyButton = true;

            decimalPoint = false;

            mySinButton = false;
            myCosButton = false;
            myTanButton = false;

            mySqrt = false;
            myCbert = false;
            myInverse = false;
        }

        private void sinButton_Click(object sender, EventArgs e)
        {
            plusButton = false;
            minusButton = false;
            divideButton = false;
            multiplyButton = false;

            decimalPoint = false;

            mySinButton = true;
            myCosButton = false;
            myTanButton = false;

            mySqrt = false;
            myCbert = false;
            myInverse = false;
        }

        private void cosButton_Click(object sender, EventArgs e)
        {
            plusButton = false;
            minusButton = false;
            divideButton = false;
            multiplyButton = false;

            decimalPoint = false;

            mySinButton = false;
            myCosButton = true;
            myTanButton = false;

            mySqrt = false;
            myCbert = false;
            myInverse = false;
        }

        private void tanButton_Click(object sender, EventArgs e)
        {
            plusButton = false;
            minusButton = false;
            divideButton = false;
            multiplyButton = false;

            decimalPoint = false;

            mySinButton = false;
            myCosButton = false;
            myTanButton = true;

            mySqrt = false;
            myCbert = false;
            myInverse = false;
        }

        private void squareRootButton_Click(object sender, EventArgs e)
        {
            plusButton = false;
            minusButton = false;
            divideButton = false;
            multiplyButton = false;

            decimalPoint = false;

            mySinButton = false;
            myCosButton = false;
            myTanButton = false;

            mySqrt = true;
            myCbert = false;
            myInverse = false;
        }

        private void cubeRootButton_Click(object sender, EventArgs e)
        {
            plusButton = false;
            minusButton = false;
            divideButton = false;
            multiplyButton = false;

            decimalPoint = false;

            mySinButton = false;
            myCosButton = false;
            myTanButton = false;

            mySqrt = false;
            myCbert = true;
            myInverse = false;
        }

        private void inverseButton_Click(object sender, EventArgs e)
        {
            plusButton = false;
            minusButton = false;
            divideButton = false;
            multiplyButton = false;

            decimalPoint = false;

            mySinButton = false;
            myCosButton = false;
            myTanButton = false;

            mySqrt = false;
            myCbert = false;
            myInverse = true;
        }
    }
}
